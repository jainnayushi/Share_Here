/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
*/

package oop.ica.part1;

/**
 *
 * @author s3139494
 */
public class ArtPrint {

    private int id;
    private String title;
    private String artist;
    private String material;
    private double price;
    private int stock;

    public ArtPrint(int id, String title, String artist, String material, double price, int stock) {
        this.id = id;
        this.title = title;
        this.artist = artist;
        this.material = material;
        this.price = price;
        this.stock = stock;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getArtist() {
        return artist;
    }

    public String getMaterial() {
        return material;
    }

    public double getPrice() {
        return price;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }


}
